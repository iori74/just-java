package com.example.justjava;

import android.app.Activity;
import android.view.View;

public class MainActivity extends Activity {
    public void submitOrder(View view) {
    }
}
